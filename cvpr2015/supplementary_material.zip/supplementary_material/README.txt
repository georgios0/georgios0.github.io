In the supplementary material we include the following 4 folders:
(1) Temporal Texture Synthesis: It contains 6 synthesized texture video sequences
(2) Texture Qualitative Function: It contains 4 video sequences, which show synthesized 
textures ordered in terms of similarity with the input texture
(3) Video Compression: Contains 1 video, which contains 12 video sequences from 
MOSEG encoded at 2 different levels of compression for textures (40% and 60%)
(4) Dataset: An image including all images of the dataset used to examine the TQF
